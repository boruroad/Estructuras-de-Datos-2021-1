					Práctica 4
/**
 * Bonilla Ruíz Roberto Adrián // Num. Cta. 31721903-8
 */
Descripción general de la práctica: Uso de colas, archivos, creación y uso de clases, interacción con el usuario
Inconvenientes que se presentaron: ACTIVIDAD 2 del PDF
Comentarios: MUCHA contradiccion, en los videos decian una cosa y por correo otra eso confundia lo que debia hacer (igual en PDF pedian un método que verificara las mesas disponibles, pero por correo me decian que era atender cliente por cliente y que todas las demás mesas debian estar libres, entonces puse ese método pero en verdad no se para que lo pedian si no se iba a usar)
