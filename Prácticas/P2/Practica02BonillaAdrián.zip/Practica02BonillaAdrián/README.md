/**
 * Bonilla Ruíz Roberto Adrián // Num. Cta. 31721903-8
 */
Descripción general de la práctica: Creación y muestra de Anagramas usando arreglos 
Inconvenientes que se presentaron: EL método rotator (fue el que más se me complico)
Comentarios: Entendí mucho mejor el funcionamiento del for