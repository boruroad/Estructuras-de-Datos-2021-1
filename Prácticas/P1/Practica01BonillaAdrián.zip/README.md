/**
 * Bonilla Ruíz Roberto Adrián // Num. Cta. 31721903-8
 */
Descripción general de la práctica: Operaciones con matrices, asi como el uso de ficheros, excepciones e interfaces en JAVA.
Inconvenientes que se presentaron: desarrollar la práctica usando ant (fue muy tardado).
Comentarios: Sentí (demasiado) muy pesada esta practica. 
Funcionamiento de la práctica: aplicamos varias operaciones útiles del álgebra lineal desde un enfoque orientado a objetos usando la programación.  