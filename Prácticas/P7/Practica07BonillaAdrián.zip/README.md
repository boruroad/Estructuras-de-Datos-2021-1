					Práctica 7: Tablas de dispersión.
/**
 * Bonilla Ruíz Roberto Adrián // Num. Cta. 31721903-8
 */
Descripción general de la práctica: Creacioón, uso y mezcla de tablas de disperción con archivos XML  
Inconvenientes que se presentaron: Comprender mejor la clase ChainHashMap y la validación de sintaxis 
Comentarios: Fue una practica que me gustó más por la manera en que implementé ciertas funciones, pero honestamente no se si volveria a hacerla.