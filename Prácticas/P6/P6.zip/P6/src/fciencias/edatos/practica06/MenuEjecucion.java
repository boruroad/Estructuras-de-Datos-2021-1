package fciencias.edatos.practica06;

/**
 * Práctica 6: Árboles binarios de búsqueda.
 * Estructura de Datos 2021-1.
 * @author Bonilla Ruiz Roberto Adrián 
 * Num. Cta. 31721903-8
 * @version 1.0
 */


import java.util.Scanner;

public class MenuEjecucion{
	/**
	 * Verifica que lo que ingrese el usuario sea de tipo double.
	 * @param sc el scanner a pasar.	 
	 * @return una opción válida de tipo double
	 */
	public static double esDouble(Scanner sc){
		double n;
		while(true){
			try{
				n = Double.parseDouble(sc.nextLine());
				break;
			}catch(NumberFormatException nfe){
				System.out.println("El dato ingresado no es de tipo double");//nfe.getMessage());
				continue;
			}catch(Exception e){
				System.out.print("\n Lo sentimos, algo imprevisto sucedió \n");
				continue;
			}
		}
		return n;
	}	

	/**
	 * Verifica lo que ingrese el usuario como opción en el menú.
	 * @param sc lo que el usuario ingrese.	 
	 * @param n1 el numero minimo a ingresar.
	 * @param n2 el numero máximo a ingresar.
	 * @return una opción válida dentro de los rangos establecidos.
	 */
	public static int verificaMenuAux (Scanner sc, int n1, int n2){
		int n;
		while(true){
			try{
				n = Integer.parseInt(sc.nextLine());
				if((n < n1)|| (n >n2)){
					throw new IndexOutOfBoundsException("Ingresaste un número fuera de rango");
				}
				break;
			}catch(NumberFormatException nfe){
				System.out.print("\n Asegurate de ingresar solo números\n");
				continue;
			}catch(IndexOutOfBoundsException ioobe){
				System.out.println(ioobe.getMessage());
			}catch(Exception e){
				System.out.print("\n Lo sentimos, algo imprevisto sucedió \n");
				continue;
			}
		}
		return n;
	}	

	public static void menu(){
		Scanner sc = new Scanner(System.in);
		ArbolBinarioBusqueda<Ciudad>  a1 = new ArbolBinarioBusqueda<>();
		String ciudad ="";
		String estado="";
		double longitud=0.0;
		double latitud=0.0;
		String ciudadAux ="";
		Ciudad borrada = null;

		//LectorDOM lector = new LectorDOM();
		//EscritorDOM escritor = new EscritorDOM();
		int seleccion;
			System.out.println("Bienvenido nuestras opciones son las siguientes\n");
		do{
			System.out.println("¿Qué desea hacer?\n");
			System.out.println("1.- Agregar una ciudad al directorio");
			System.out.println("2.- Eliminar una ciudad al directorio");
			System.out.println("3.- Mostrar la información de una ciudad");
			System.out.println("4.- Determinar todas las ciudades dentro de un rango y a partir de una coordenada");
			System.out.println("5.- Salir");

			seleccion = verificaMenuAux(sc,1,5);


			switch(seleccion){
				case 1:
					try{
						Ciudad c1 = new Ciudad(null,null,0.0,0.0);
						System.out.println("Ingrese nombre de la ciudad");
						ciudad = sc.nextLine().toUpperCase();
						c1.setNombre(ciudad);

						System.out.println("Ingrese el estado al que pertenece la ciudad");
						estado = sc.nextLine();
						c1.setEstado(estado);	

						System.out.println("Ingrese la longitud de la ciudad");
						longitud = esDouble(sc);
						c1.setLongitud(longitud);

						System.out.println("Ingrese la latitud de la ciudad");
						latitud = esDouble(sc);
						c1.setLatitud(latitud);
						a1.insert(c1,ciudad);
						//System.out.println(c1);
						//System.out.println(a1);
				        //lector.lee(nombreA+".xml");
					}catch(Exception e){
						System.out.println(e.getMessage());
					}
				break;

				case 2:
						System.out.println("Ingrese el nombre de la ciudad");
						ciudadAux = sc.nextLine().toUpperCase();
						borrada = a1.delete(ciudadAux);
						if(borrada!=null){
							System.out.println(ciudadAux +" ha sido eliminada");
							System.out.println(borrada);
						}else{
							System.out.println(ciudadAux +" no se encuentra");
						}

				break;

				case 3:
					try{
						System.out.println("Ingrese el nombre de la ciudad");
						String n = sc.nextLine().toUpperCase();
						Ciudad busqueda = a1.retrieve(n);
						if(busqueda ==null){
							System.out.println("La ciudad "+n+" no fue encontrada (fue borrada o no existe)");
						}else{
							System.out.println(busqueda);	
						}
						//if(a1.retrieve(nCiudad) == null){
						//	System.out.println(nCiudad+" no se encontró");
						//}else{
						//	System.out.println(a1.retrieve(nCiudad));
						//}

					}catch(Exception e){
						System.out.println(e.getMessage());
					}
				break;
			}

		}while(seleccion!=5);
	}

	public static void main(String[] args) {
		menu();
	}


}