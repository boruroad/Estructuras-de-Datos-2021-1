					Práctica 6
/**
 * Bonilla Ruíz Roberto Adrián // Num. Cta. 31721903-8
 */
Descripción general de la práctica: Árboles binarios de búsqueda e implementacion de archivos xml.
Inconvenientes que se presentaron: Cambiar el método de "borrado" que nos fue dado (tenia errores) y la actividad 2 
Comentarios: Fue una práctica que honestamente no me agrado, xml me confunde demasiado pero de que aprendí, aprendí. Lo más talachudo fue el punto 4 de la Actividad 1  