#Práctica de Reposición: Pilas

## Autor: 
   Bonilla Ruíz Roberto Adrián 

## Número de cuenta:
   31721903-8

## Descripción general de la práctica:
   Creación, uso y mezcla de pilas con archivos XML  

## Inconvenientes que se presentaron:
   Almacenar las cadenas a insertar de la pila en un archivo XML

## Comentarios:
   Fue una practica que me gustó mucho, sin duda EDD se volvió una de mis materias favoritas, supongo que 			esta fue mi última practica antes del proyecto. Pilas es un tema muy padre. 