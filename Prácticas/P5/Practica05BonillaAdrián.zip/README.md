					Práctica 5
/**
 * Bonilla Ruíz Roberto Adrián // Num. Cta. 31721903-8
 */
Descripción general de la práctica: Aplicaciones de árboles y uso de archivos XML
Inconvenientes que se presentaron: Lectura de los archivos como tal
Comentarios: Fue una práctica corta pero de mucho aprendizaje, nunca habia hecho nada relacionado con esto