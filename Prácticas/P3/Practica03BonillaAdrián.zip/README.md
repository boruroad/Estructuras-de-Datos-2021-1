					Práctica 3
/**
 * Bonilla Ruíz Roberto Adrián // Num. Cta. 31721903-8
 */
Descripción general de la práctica: Uso de listas mezclado con genéricos y archivos
Inconvenientes que se presentaron: La actividad 1 y enumerar a los empleados (demore dos dias en ello)
Comentarios: Es una práctica que me recuerda a un proyecto de ICC, (me gustó) pero en más de una ocasión me frustaba que no salieran las cosas como esperaba.
(Cada vez le voy perdiendo más el miedo al uso del for)